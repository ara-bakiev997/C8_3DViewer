#ifndef WIDGET_H
#define WIDGET_H

#include <QOpenGLWidget>
#include <QMatrix4x4>
#include <QOpenGLShaderProgram>
#include <QOpenGLTexture>
#include <QOpenGLBuffer>
#include <QOpenGLFunctions>

struct VertexData {

    VertexData() {}

    VertexData(QVector3D p, QVector2D t, QVector3D n) : position (p),
        texCoord(t), normal(n) {}

    QVector3D position;
    QVector2D texCoord;
    QVector3D normal;
};

class Widget : public QOpenGLWidget, QOpenGLFunctions
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

protected:

    void initializeGL(); //вызывается один раз, при создании приложения
    void resizeGL(int w, int h); //вызывается при масштабировании окна
    void paintGL(); //можно вызвать принудительно методом update()

    void initShaders();

    void initCube(float width);

private:

    QMatrix4x4 ProjectionMatrix; //для вычисления перспективы, отрисовки

    QOpenGLShaderProgram ShaderProgram;

    QOpenGLTexture *m_texture;

    QOpenGLBuffer ArrayBuffer; //вершинный буфер. для передачи информации вершинному шейдеру.

    QOpenGLBuffer IndexBuffer; //пиксельный буфер
};
#endif // WIDGET_H
